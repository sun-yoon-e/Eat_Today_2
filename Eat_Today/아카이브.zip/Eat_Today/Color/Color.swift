//
//  Color.swift
//  Eat_Today
//
//  Created by KPUGAME on 2021/06/05.
//

import Foundation

class Color {
    var r: Int = 0
    var g: Int = 0
    var b: Int = 0
    
    init() {
        r = 255
        b = 255
        g = 255
    }
}
